package com.example.CustomerManagement.Service;

import com.example.CustomerManagement.DTO.SaveCustomerDto;
import com.example.CustomerManagement.DTO.UpdateCustomerDto;
import com.example.CustomerManagement.Model.Customer;

import java.util.List;

public interface CustomerService {
    void addCustomer(SaveCustomerDto saveCustomerDto);

    List<Customer> getAllCustomers();

    void updateCustomer(UpdateCustomerDto updateCustomerDto);

    void deleteCustomer(int id);
}
