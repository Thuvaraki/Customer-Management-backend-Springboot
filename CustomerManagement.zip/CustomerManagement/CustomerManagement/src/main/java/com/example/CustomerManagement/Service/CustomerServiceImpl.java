package com.example.CustomerManagement.Service;

import com.example.CustomerManagement.DTO.SaveCustomerDto;
import com.example.CustomerManagement.DTO.UpdateCustomerDto;
import com.example.CustomerManagement.Model.Customer;
import com.example.CustomerManagement.Repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService{
    @Autowired
    private CustomerRepository customerRepository;
    @Override
    public void addCustomer(SaveCustomerDto saveCustomerDto) {
        Customer customer = new Customer(
                saveCustomerDto.getName(),
                saveCustomerDto.getAddress(),
                saveCustomerDto.getMobile()
                );
        customerRepository.save(customer);
    }

    @Override
    public List<Customer> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        return customers;
    }

    @Override
    public void updateCustomer(UpdateCustomerDto updateCustomerDto) {
        if (customerRepository.existsById(updateCustomerDto.getId())) {
            Customer customer = customerRepository.getById(updateCustomerDto.getId());
            customer.setName(updateCustomerDto.getName());
            customer.setAddress(updateCustomerDto.getAddress());
            customer.setMobile(updateCustomerDto.getMobile());
            customerRepository.save(customer);
        } else {
            System.out.println("Customer ID do not Exist");
        }
    }

    @Override
    public void deleteCustomer(int id) {
        if (customerRepository.existsById(id)) {
            customerRepository.deleteById(id);
        } else {
            System.out.println("customer id not found");
        }
    }


}
