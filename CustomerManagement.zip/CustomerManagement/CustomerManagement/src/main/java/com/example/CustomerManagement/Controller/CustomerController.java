package com.example.CustomerManagement.Controller;

import com.example.CustomerManagement.DTO.SaveCustomerDto;
import com.example.CustomerManagement.DTO.UpdateCustomerDto;
import com.example.CustomerManagement.Model.Customer;
import com.example.CustomerManagement.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("api/v1/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping(path = "/save")
    public void addCustomer(@RequestBody SaveCustomerDto saveCustomerDto){
        customerService.addCustomer(saveCustomerDto);
    }

    @GetMapping(path = "/getAllCustomers")
    public List<Customer> getAllCustomer(){
        List<Customer> customers = customerService.getAllCustomers();
        return customers;
    }

    @PutMapping(path = "/update")
    public void updateCustomer(@RequestBody UpdateCustomerDto updateCustomerDto){
        customerService.updateCustomer(updateCustomerDto);
    }

    @DeleteMapping(path = "/deletecustomer/{id}")
    public void deleteCustomer(@PathVariable("id") int id){

        customerService.deleteCustomer(id);
    }
}
