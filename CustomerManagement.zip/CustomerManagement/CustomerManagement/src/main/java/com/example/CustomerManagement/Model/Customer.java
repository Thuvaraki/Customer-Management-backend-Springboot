package com.example.CustomerManagement.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "customer_id", length = 50)
    private int id;

    @Column(name = "customer_name", length = 50)
    private String name;

    @Column(name = "customer_address", length = 60)
    private String address;

    @Column(name = "mobile", length = 10)
    private int mobile;

    public Customer(String name, String address, int mobile) {
        this.name = name;
        this.address = address;
        this.mobile = mobile;
    }
}
